namespace rerun::components {
#if 0
    // <CODEGEN_COPY_TO_HEADER>

    TransformMat3x3(const rerun::datatypes::Vec3D (&columns)[3]) : matrix(columns) {}

    // </CODEGEN_COPY_TO_HEADER>
#endif
} // namespace rerun::components
