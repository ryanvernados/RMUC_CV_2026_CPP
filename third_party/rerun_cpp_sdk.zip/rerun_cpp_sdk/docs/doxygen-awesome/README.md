Doxygen Awesome
===============

This is a copy of [Doxygen Awesome](https://github.com/jothepro/doxygen-awesome-css) version [2.2.1]
(https://github.com/jothepro/doxygen-awesome-css/releases/tag/v2.2.1)

